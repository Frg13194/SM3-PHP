# Examples
Composer 库 ch4o5/SM3-PHP 的使用示例

## 快速上手
1. `composer install`
2. `php ./sm3_function.php`

## 项目结构
* sm3_function.php 

  `sm3()` 语法糖的使用示例
  
* sm3_object.php 
  
  标准 `sm3-php` 库的面向对象使用示例，
  并进行了输出结果和使用方式的详细说明